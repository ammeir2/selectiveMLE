# selectiveMLE
A package for computing the selective MLE for the lasso
